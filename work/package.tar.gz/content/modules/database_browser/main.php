<?php
function database_browser_render() {
	return "";
}