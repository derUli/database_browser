<?php
define ( "TRANSLATION_LIST_OF_TABLES", "Liste der Tabellen" );
define ( "TRANSLATION_TABLE_X", "Tabelle \"%x\"" );
define ( "TRANSLATION_BACK_TO_LIST", "Zurück zur Liste" );