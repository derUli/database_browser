<?php
define ( "TRANSLATION_LIST_OF_TABLES", "List of Tables" );
define ( "TRANSLATION_TABLE_X", "Table \"%x\"" );
define ( "TRANSLATION_BACK_TO_LIST", "Back to List" );